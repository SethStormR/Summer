Davinci Resolve Summer icons
-----------------------------
Copy all the image files to /opt/resolve/graphics