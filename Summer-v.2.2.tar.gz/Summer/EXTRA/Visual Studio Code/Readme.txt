Visual Studio Code Summer icon
-----------------------------
Copy the *.png image file to /opt/apps/com.visualstudio.code/files/share/pixmaps